================================================================================
GLOBAL DUB PLATE - WINDOWS DESKTOP EDITION
FL Studio Emulation • Multitrack Arranger • Floating Mixer • Sound Clash Desk
================================================================================

HOW TO RUN ON WINDOWS 10 & 11:
1. Extract all files from this ZIP package to any folder (e.g. C:\GlobalDubPlate or Desktop).
2. Double-click "Launch-Global-Dub-Plate.bat" (or right-click Launch-Global-Dub-Plate.ps1 -> Run with PowerShell).
3. The Global Dub Plate audio engine will boot and immediately launch in a dedicated, 
   borderless 60fps hardware-accelerated DAW window!

KEYBOARD SHORTCUTS:
- F5       : Bring Out / Focus Playlist Arrangement
- F9       : Bring Out / Toggle Floating Mixer Window
- Space    : Start / Stop Playback
- Ctrl + M : Toggle Metronome Click
- Ctrl + P : Toggle 3-2-1 Countdown Pre-Count

REQUIREMENTS:
- Node.js (https://nodejs.org) - LTS version recommended.
- Microsoft Edge or Google Chrome (Pre-installed on Windows 10/11 for borderless DAW mode).

--------------------------------------------------------------------------------
PROJECT & CREATOR ATTRIBUTION:
This project was made by Adrian Anesu Mupemhi for Jahvisions, Benjamin Music & Terence Taona Technologies.
Owner: Adrian Anesu Mupemhi | Contact: +2772442 5958 | Address: 34 Derby Road, Kensington, Johannesburg, South Africa, 2094 | Email: mupemhianesu@gmail.com
--------------------------------------------------------------------------------

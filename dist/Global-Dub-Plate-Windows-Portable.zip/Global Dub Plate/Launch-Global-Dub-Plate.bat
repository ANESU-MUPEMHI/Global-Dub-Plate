@echo off
setlocal
title Global Dub Plate DAW - Windows Desktop Launcher
color 0b
echo ===============================================================================
echo   GLOBAL DUB PLATE DAW - DIGITAL AUDIO WORKSTATION (FL STUDIO EMULATION)
echo   Sound Clash Desk ^| Multitrack Arranger ^| Floating Mixer Console
echo   Created by Adrian Anesu Mupemhi
echo   For Jahvisions, Benjamin Music ^& Terence Taona Technologies
echo ===============================================================================
echo.

cd /d "%~dp0"
set PORT=3333
set URL=http://localhost:%PORT%

rem Verify Node.js is present
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
  echo [ERROR] Node.js was not found in your system PATH.
  echo Please download and install Node.js (https://nodejs.org) to launch Global Dub Plate.
  echo.
  pause
  exit /b 1
)

echo [*] Starting Global Dub Plate Audio Engine on %URL%...
start /b "" node server.js > "%TEMP%\global-dub-plate.log" 2>&1

echo [*] Initializing 6-Track Web Audio engine ^& Escrow gates...
timeout /t 2 /nobreak >nul

rem Find Edge or Chrome to launch in dedicated borderless 60fps app window mode
set BROWSER_BIN=
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  set "BROWSER_BIN=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
  set "BROWSER_BIN=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  set "BROWSER_BIN=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
  set "BROWSER_BIN=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
) else if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
  set "BROWSER_BIN=%LocalAppData%\Google\Chrome\Application\chrome.exe"
)

if defined BROWSER_BIN (
  echo [*] Launching Global Dub Plate in standalone borderless desktop window...
  start "" "%BROWSER_BIN%" --app="%URL%" --window-size=1360,860 --app-id="global-dub-plate-daw" --autoplay-policy=no-user-gesture-required
) else (
  echo [*] Opening default web browser...
  start %URL%
)

echo.
echo ===============================================================================
echo   Global Dub Plate is active! Keep this window open while using the DAW.
echo   Press Ctrl + C or close this window to stop the audio engine.
echo ===============================================================================
echo.
pause

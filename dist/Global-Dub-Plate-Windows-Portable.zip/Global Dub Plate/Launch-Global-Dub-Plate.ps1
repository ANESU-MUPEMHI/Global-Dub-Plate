# Global Dub Plate - Windows PowerShell Desktop Launcher
# Created by Adrian Anesu Mupemhi for Jahvisions, Benjamin Music & Terence Taona Technologies

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir
$Port = 3333
$Url = "http://localhost:$Port"

Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host "  GLOBAL DUB PLATE DAW - WINDOWS DESKTOP LAUNCHER" -ForegroundColor Yellow
Write-Host "  FL Studio Emulation | Floating Mixer | Multitrack Sound Clash Desk" -ForegroundColor Gray
Write-Host "===============================================================================" -ForegroundColor Cyan

# Test Node.js
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] Node.js is required to run Global Dub Plate." -ForegroundColor Red
    Write-Host "Please install Node.js from https://nodejs.org" -ForegroundColor White
    Read-Host "Press Enter to exit..."
    exit 1
}

Write-Host "[*] Booting internal audio server..." -ForegroundColor Green
$ProcessInfo = New-Object System.Diagnostics.ProcessStartInfo
$ProcessInfo.FileName = "node"
$ProcessInfo.Arguments = "server.js"
$ProcessInfo.WorkingDirectory = $ScriptDir
$ProcessInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
[System.Diagnostics.Process]::Start($ProcessInfo) | Out-Null

Start-Sleep -Seconds 2

# Check for Edge or Chrome
$Edge = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
$Chrome = "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe"


if (Test-Path $Edge) {
    Start-Process $Edge -ArgumentList "--app=$Url --window-size=1360,860 --autoplay-policy=no-user-gesture-required"
} elseif (Test-Path $Chrome) {
    Start-Process $Chrome -ArgumentList "--app=$Url --window-size=1360,860 --autoplay-policy=no-user-gesture-required"
} else {
    Start-Process $Url
}

Write-Host "[OK] Global Dub Plate is running at $Url" -ForegroundColor Green
